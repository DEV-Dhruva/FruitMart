
<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
 
// If necessary, modify the path in the required statement below to refer to the
// location of your Composer autoload.php file.
//require 'PHPMailer/src/Exception.php';
//require 'PHPMailer/src/PHPMailer.php';
//require 'PHPMailer/src/SMTP.php';
 
require './vendor/autoload.php';

// This email address must be verified with Amazon SES to send.
$sender = '13prem.patel@gmail.com';
$senderName = 'Fruitmart';
 
// is still in the sandbox, this address must be verified.
$recipient = 'dhruvaludbe1@gmail.com';
 
// Replace smtp_username with your Amazon SES SMTP user name.
$username = 'AKIATJQ7PA2UZ7UNVEUM';
 
// Replace smtp_password with your Amazon SES SMTP password.
$password = 'BBw564mfkrJQV1+o+JCUfJCojT9m1ZASxfV7snfB57dK';
 
 
// If you're using Amazon SES in a region other than US West (Oregon),
// replace email-smtp.us-west-2.amazonaws.com with the Amazon SES SMTP
// endpoint in the appropriate region.
$host = 'email-smtp.ap-south-1.amazonaws.com '; // please enter you endpoint
$port = 587;
 
// The subject line of the email
$subject = 'Fruitmart Orders';
 
// If you are sending The plain-text body of the email then uncomment below code line
$bodyText =  "Email Confirm";
 
// The HTML-formatted body of the email
$bodyHtml = "Your Order Has been Confirmed!"."\n"."Please Check the Website for Ordered Details";
 
$mail = new PHPMailer(true);
 
try {
    // Specify the SMTP settings.
    $mail->isSMTP();
    $mail->setFrom($sender, $senderName);
    $mail->Username   = $username;
    $mail->Password   = $password;
    $mail->Host       = $host;
    $mail->Port       = $port;
    $mail->SMTPAuth   = true;
    $mail->SMTPSecure = 'tls';
  //  $mail->addCustomHeader('X-SES-CONFIGURATION-SET', $configurationSet);
 
    // Specify the message recipients.
    $mail->addAddress($recipient);
    // You can also add CC, BCC, and additional To recipients here.
 
    //If you want to send reply to specific email , then use below code for Reply To
    //$mail->ClearReplyTos();
    //$mail->addReplyTo('Enter Reply to Email here', 'Enter Reply to name here');
 
    //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
 
    // Specify the content of the message.
    //$mail->isHTML(true);
    $mail->Subject    = $subject;
    $mail->Body       = $bodyHtml;
    $mail->AltBody    = $bodyText;
    $mail->Send();
    echo "Email sent successfully!";
    header('location:../home.php');
} catch (phpmailerException $e) {
    echo "An error occurred. {$e->errorMessage()}", PHP_EOL; //Catch errors from PHPMailer.
} catch (Exception $e) {
    echo "Email not sent. {$mail->ErrorInfo}", PHP_EOL; //Catch errors from Amazon SES.
}
?>