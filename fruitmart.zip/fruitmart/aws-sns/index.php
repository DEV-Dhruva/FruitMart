<?php
/** Make sure to add autoload.php */
require './vendor/autoload.php';
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);
   
      $params = array(
         'credentials' => array(
            'key' => 'AKIATJQ7PA2U6RRUM3Y5',
            'secret' => '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',
         ),
         'region' => 'ap-south-1',
         'version' => 'latest'
      );
      $sns = new \Aws\Sns\SnsClient($params);

      $args = array(
         "MessageAtributes" => [
            // 'AWS.SNS.SMS.SenderID' => [
            //     'DataType' => 'String',
            //     'StringValue' => 'Dhruva'
            // ],
            'AWS.SNS.SMS.SMSTYPE' => [
                  'DataType' => 'String',
                  'StringValue' => 'Transactional'
            ]
            ],
            "Message" => "000000",
            "PhoneNumber" => "+919870191718"
         );

         $result = $sns->publish($args);
         // echo "<pre>";
         // var_dump($result);
         // echo "</pre>";


?>





